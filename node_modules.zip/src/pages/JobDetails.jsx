import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import '../styles/JobDetails.css';

const JobDetails = () => {
    const { id } = useParams(); // URL se Job ID nikalne ke liye
    const navigate = useNavigate();

    // Dummy data (Baad mein ye backend se aayega)
    const job = {
        title: "Software Engineer Intern",
        company: "Google",
        location: "Bangalore",
        salary: "1.5 Lakh/Month",
        description: "We are looking for a passionate developer who knows React and Node.js. You will work on real-world projects.",
        requirements: ["React knowledge", "Good communication", "Problem solving"],
        deadline: "March 15, 2026"
    };

    return (
        <div className="job-details-page">
            <Navbar />
            <div className="details-container">
                <button className="back-btn" onClick={() => navigate(-1)}>⬅ Back</button>
                <div className="details-card">
                    <h1>{job.company} - {job.title}</h1>
                    <div className="info-grid">
                        <p><strong>📍 Location:</strong> {job.location}</p>
                        <p><strong>💰 Salary:</strong> {job.salary}</p>
                        <p><strong>⏳ Deadline:</strong> {job.deadline}</p>
                    </div>
                    <hr />
                    <h3>Job Description:</h3>
                    <p>{job.description}</p>
                    <h3>Requirements:</h3>
                    <ul>
                        {job.requirements.map((req, index) => <li key={index}>{req}</li>)}
                    </ul>
                    <button className="apply-now-btn" onClick={() => alert("Applied Successfully!")}>
                        Confirm Application
                    </button>
                </div>
            </div>
        </div>
    );
};

export default JobDetails;