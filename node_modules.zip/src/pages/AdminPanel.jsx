import React, { useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar'; // Navbar ko import karna mat bhulna
import '../styles/AdminPanel.css'; // CSS file ko link kiya

const AdminPanel = () => {
    // Form data handle karne ke liye state
    const [jobData, setJobData] = useState({
        company: '',
        role: '',
        package: '',
        deadline: ''
    });

    // Input change handle karne ke liye
    const handleChange = (e) => {
        setJobData({ ...jobData, [e.target.name]: e.target.value });
    };

    // SQL Database mein data bhejne ka function
    const handleSubmit = async (e) => {
        e.preventDefault();

        // Check ki koi field khali na ho
        if (!jobData.company || !jobData.role || !jobData.package || !jobData.deadline) {
            alert("Kripya saari details bhariye! ⚠️");
            return;
        }

        try {
            // Member 2 ka Backend API call
            const response = await axios.post('http://localhost:5000/api/addjob', jobData);
            
            if (response.status === 200) {
                alert("Success: Job SQL Database mein save ho gayi! 🚀");
                // Form clear karna
                setJobData({ company: '', role: '', package: '', deadline: '' });
            }
        } catch (error) {
            console.error("Backend Error:", error);
            alert("Server Error: Kya aapne backend ka 'node index.js' chalu kiya hai?");
        }
    };

    return (
        <div className="admin-page-wrapper">
            {/* 1. Top Navbar */}
            <Navbar />

            <div className="admin-main-container">
                <div className="admin-form-card">
                    <header className="admin-card-header">
                        <h2>Add New Job Opportunity 👨‍💼</h2>
                        <p>Fill the details below to post a job for students.</p>
                    </header>

                    <form onSubmit={handleSubmit} className="admin-stylish-form">
                        <div className="form-input-group">
                            <label>Company Name</label>
                            <input 
                                type="text" 
                                name="company" 
                                placeholder="e.g. Google, Microsoft" 
                                value={jobData.company} 
                                onChange={handleChange} 
                            />
                        </div>

                        <div className="form-input-group">
                            <label>Job Role</label>
                            <input 
                                type="text" 
                                name="role" 
                                placeholder="e.g. Frontend Developer" 
                                value={jobData.role} 
                                onChange={handleChange} 
                            />
                        </div>

                        <div className="form-input-group">
                            <label>Salary Package (LPA)</label>
                            <input 
                                type="text" 
                                name="package" 
                                placeholder="e.g. 12 LPA" 
                                value={jobData.package} 
                                onChange={handleChange} 
                            />
                        </div>

                        <div className="form-input-group">
                            <label>Application Deadline</label>
                            <input 
                                type="date" 
                                name="deadline" 
                                value={jobData.deadline} 
                                onChange={handleChange} 
                            />
                        </div>

                        <button type="submit" className="admin-post-btn">
                            Post Job to Database
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default AdminPanel;