import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import '../styles/Dashboard.css';

const Dashboard = () => {
    const [jobs, setJobs] = useState([]);
    const [loading, setLoading] = useState(true);
    
    // 1. Memory check: Refresh karne par bhi "Applied" status nahi jayega
    const [appliedJobs, setAppliedJobs] = useState(() => {
        const saved = localStorage.getItem('appliedJobs');
        return saved ? JSON.parse(saved) : [];
    });

    useEffect(() => {
        // LocalStorage update jab bhi appliedJobs badle
        localStorage.setItem('appliedJobs', JSON.stringify(appliedJobs));
    }, [appliedJobs]);

    useEffect(() => {
        const fetchJobs = async () => {
            try {
                // SQL Backend call
                const response = await axios.get('http://localhost:5000/api/getjobs');
                setJobs(response.data);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching jobs:", error);
                setLoading(false);
            }
        };
        fetchJobs();
    }, []);

    // 2. Handle Apply Function
    const handleApply = (jobId) => {
        if (!appliedJobs.includes(jobId)) {
            setAppliedJobs([...appliedJobs, jobId]);
            alert("Application Submitted Successfully! 🚀");
        }
    };

    if (loading) return <div className="loading">Connecting to Database... ⏳</div>;

    return (
        <div className="dashboard-wrapper">
            <Navbar />
            
            <div className="dashboard-container">
                {/* Stats Counter Section */}
                <div className="stats-grid">
                    <div className="stat-card">
                        <h3>{jobs.length}</h3>
                        <p>Total Jobs</p>
                    </div>
                    <div className="stat-card">
                        <h3>{appliedJobs.length}</h3>
                        <p>Applications</p>
                    </div>
                    <div className="stat-card">
                        <h3 style={{color: '#27ae60'}}>Active</h3>
                        <p>Student Status</p>
                    </div>
                </div>

                <header className="dashboard-header">
                    <h1>Placement Dashboard</h1>
                    <p>Track your applications and explore new opportunities</p>
                </header>

                <div className="job-grid">
                    {jobs.length > 0 ? (
                        jobs.map((job) => (
                            <div key={job.id} className="job-card">
                                <div className="company-logo">
                                    {job.company ? job.company[0].toUpperCase() : 'J'}
                                </div>
                                <div className="job-info">
                                    <h3>{job.role}</h3>
                                    <p className="company-name">🏢 {job.company}</p>
                                    <div className="job-meta">
                                        <span>💰 {job.package}</span>
                                        <span>📅 {job.deadline}</span>
                                    </div>
                                    
                                    {/* 3. Conditional Button Logic */}
                                    <button 
                                        onClick={() => handleApply(job.id)} 
                                        className={appliedJobs.includes(job.id) ? "applied-btn" : "apply-btn"}
                                        disabled={appliedJobs.includes(job.id)}
                                    >
                                        {appliedJobs.includes(job.id) ? "Applied ✅" : "Apply Now"}
                                    </button>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="no-data">
                            <h3>No Openings Available!</h3>
                            <p>Check back later or contact Admin.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;