import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.removeItem('userRole');
  }, []);

  const handleLogin = (e) => {
    e.preventDefault();
    if (email === "admin@college.com" && password === "admin123") {
      localStorage.setItem('userRole', 'admin');
      navigate('/admin');
    } else if (email.toLowerCase().endsWith("@college.edu")) {
      localStorage.setItem('userRole', 'student');
      navigate('/dashboard');
    } else {
      alert("Invalid Credentials! Student email should end with @college.edu");
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-header">
          <h1>Placement Portal</h1>
          <p>Sign in to continue your journey</p>
        </div>
        
        <form onSubmit={handleLogin} className="login-form">
          <div className="input-group">
            <label>Email Address</label>
            <input 
              type="email" 
              placeholder="name@college.edu" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              required 
            />
          </div>
          
          <div className="input-group">
            <label>Password</label>
            <input 
              type="password" 
              placeholder="••••••••" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              required 
            />
          </div>
          
          <button type="submit" className="login-btn">Login Now</button>
        </form>

        <div className="login-footer">
          <p>Admin: admin@college.com | admin123</p>
          <p>Student: use any @college.edu email</p>
        </div>
      </div>
    </div>
  );
};

export default Login;