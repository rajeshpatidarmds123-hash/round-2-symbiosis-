import React from 'react';
import Navbar from '../components/Navbar';

const Profile = () => {
  const role = localStorage.getItem('userRole');
  
  return (
    <div>
      <Navbar />
      <div style={{padding: '40px', display: 'flex', justifyContent: 'center'}}>
        <div style={{
          background: 'white', padding: '40px', borderRadius: '15px', 
          boxShadow: '0 5px 25px rgba(0,0,0,0.1)', textAlign: 'center', width: '350px'
        }}>
          <div style={{
            width: '80px', height: '80px', background: '#3498db', borderRadius: '50%', 
            margin: '0 auto 20px', display: 'flex', alignItems: 'center', 
            justifyContent: 'center', color: 'white', fontSize: '30px'
          }}>👤</div>
          <h2>My Profile</h2>
          <hr style={{border: '0.5px solid #eee'}} />
          <p style={{marginTop: '20px'}}><strong>User Type:</strong> {role.toUpperCase()}</p>
          <p><strong>Status:</strong> Placement Ready ✅</p>
          <p><strong>Department:</strong> B.Tech CSE</p>
          <button style={{
            marginTop: '20px', width: '100%', padding: '10px', 
            background: '#3498db', color: 'white', border: 'none', borderRadius: '5px'
          }}>Update Resume</button>
        </div>
      </div>
    </div>
  );
};

export default Profile;