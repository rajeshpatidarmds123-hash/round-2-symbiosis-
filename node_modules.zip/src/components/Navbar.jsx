import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const role = localStorage.getItem('userRole');

  const handleLogout = () => {
    localStorage.removeItem('userRole');
    navigate('/');
  };

  return (
    <nav style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '10px 40px', background: '#2c3e50', color: 'white', position: 'sticky', top: 0, zIndex: 1000
    }}>
      <h2 style={{color: '#3498db', margin: 0}}>Placement Portal</h2>
      <div style={{display: 'flex', gap: '20px', alignItems: 'center'}}>
        <Link to="/dashboard" style={{color: 'white', textDecoration: 'none'}}>Jobs</Link>
        <Link to="/profile" style={{color: 'white', textDecoration: 'none'}}>My Profile</Link>
        <button onClick={handleLogout} style={{
          background: '#e74c3c', color: 'white', border: 'none', 
          padding: '7px 15px', borderRadius: '5px', cursor: 'pointer'
        }}>Logout</button>
      </div>
    </nav>
  );
};

export default Navbar;