import React from 'react';

const Footer = () => {
    return (
        <footer style={{ textAlign: 'center', padding: '20px', background: '#f1f5f9', marginTop: '40px', color: '#64748b' }}>
            <p>© 2026 College Placement Cell | Built for Hackathon</p>
        </footer>
    );
};

export default Footer;