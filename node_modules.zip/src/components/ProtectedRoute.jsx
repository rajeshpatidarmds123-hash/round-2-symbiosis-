import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children, isAdmin = false }) => {
  const userRole = localStorage.getItem('userRole');

  // Agar login nahi hai toh seedha Login page par bhej do
  if (!userRole) {
    return <Navigate to="/" replace />;
  }

  // Agar user Student hai aur Admin page kholne ki koshish kare
  if (isAdmin && userRole !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }

  // Agar user Admin hai aur Dashboard kholne ki koshish kare toh bhi allow hai
  // ya fir Student hai toh Dashboard dikhao
  return children;
};

export default ProtectedRoute;